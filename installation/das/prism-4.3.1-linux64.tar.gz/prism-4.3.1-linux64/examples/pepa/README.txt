These examples are adapted from those on the PEPA webpage:

http://www.dcs.ed.ac.uk/pepa/examples.html
