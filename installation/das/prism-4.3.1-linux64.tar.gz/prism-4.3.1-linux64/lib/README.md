To simplify maintenance of scripts and config files, we mostly omit version numbers in the filenames of the various libraries included here. For reference, they are:

* colt.jar - Colt version 1.2.0
* epsgraphics.jar - EPS Graphics version 1.0.0
* jas.jar - Java Algebra System (JAS) version 2.5.5246
* log4j.jar - Apache log4j (dependency of JAS)
* jcommon.jar - JCommon, version 1.0.16
* jfreechart.jar - JFreeChart, version 1.0.13
* jhoafparser.jar - jhoafparser, version 1.1.0

See here for more details and links:

http://www.prismmodelchecker.org/other-downloads.php


